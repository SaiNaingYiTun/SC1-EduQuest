require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
 
const app = express();
 
// ===== MIDDLEWARE =====
app.use(cors());
app.use(express.json());
 
// ===== DATABASE CONNECTION =====
const MONGODB_URI =
  process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/eduquest';
 
mongoose
  .connect(MONGODB_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB');
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err);
  });
 
// ===== SCHEMAS & MODELS =====
 
// Subdocument for questions
const questionSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },
    question: { type: String, required: true },
    options: { type: [String], default: [] },
    correctAnswer: { type: Number, required: true },
    explanation: { type: String, default: '' }
  },
  { _id: false }
);
 
// Quest schema
const questSchema = new mongoose.Schema(
  {
    // we keep our own "id" field so frontend doesn't need changes
    id: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    difficulty: { type: String, default: 'Easy' },
    xpReward: { type: Number, default: 0 },
    timeLimit: { type: Number, default: null },
    teacherId: { type: String, default: null },
    questions: { type: [questionSchema], default: [] }
  },
  { timestamps: true }
);
 
const Quest = mongoose.model('Quest', questSchema);

const studentStateSchema = new mongoose.Schema(
  {
    studentId: { type: String, required: true, unique: true },
 
    // progress per quest: { questId: score }
    progress: {
      type: Map,
      of: Number,
      default: {}
    },
 
    // level & xp
    level: { type: Number, default: 1 },
    xp: { type: Number, default: 0 },
 
    // inventory: array of any item objects you already use
    inventory: {
      type: [Object],
      default: []
    },
 
    // achievements: array of objects
    achievements: {
      type: [Object],
      default: []
    }
  },
  { timestamps: true }
);
 
const StudentState = mongoose.model('StudentState', studentStateSchema);
// ===== ROUTES =====
 
// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    backend: 'EduQuest API',
    time: new Date()
  });
});
 
// Get all quests
app.get('/api/quests', async (req, res) => {
  try {
    const quests = await Quest.find().lean();
    res.json(quests);
  } catch (err) {
    console.error('Error fetching quests:', err);
    res.status(500).json({ message: 'Failed to fetch quests' });
  }
});
 
// Get a single quest by id
app.get('/api/quests/:id', async (req, res) => {
  try {
    const quest = await Quest.findOne({ id: req.params.id }).lean();
    if (!quest) {
      return res.status(404).json({ message: 'Quest not found' });
    }
    res.json(quest);
  } catch (err) {
    console.error('Error fetching quest:', err);
    res.status(500).json({ message: 'Failed to fetch quest' });
  }
});
 
// Create a new quest
app.post('/api/quests', async (req, res) => {
  try {
    const body = req.body;
 
    if (!body.title || !body.description) {
      return res
        .status(400)
        .json({ message: 'title and description are required' });
    }
 
    // generate an id if not provided
    const questId = body.id || `quest_${Date.now()}`;
 
    const newQuest = new Quest({
      id: questId,
      title: body.title,
      description: body.description,
      difficulty: body.difficulty || 'Easy',
      xpReward: body.xpReward || 0,
      timeLimit: body.timeLimit ?? null,
      teacherId: body.teacherId || null,
      questions: body.questions || []
    });
 
    const savedQuest = await newQuest.save();
    res.status(201).json(savedQuest);
  } catch (err) {
    console.error('Error creating quest:', err);
    res.status(500).json({ message: 'Failed to create quest' });
  }
});
 
// Update an existing quest
app.put('/api/quests/:id', async (req, res) => {
  try {
    const questId = req.params.id;
    const updates = req.body;
 
    const updatedQuest = await Quest.findOneAndUpdate(
      { id: questId },
      updates,
      { new: true } // return updated doc
    ).lean();
 
    if (!updatedQuest) {
      return res.status(404).json({ message: 'Quest not found' });
    }
 
    res.json(updatedQuest);
  } catch (err) {
    console.error('Error updating quest:', err);
    res.status(500).json({ message: 'Failed to update quest' });
  }
});
 
// Delete a quest
app.delete('/api/quests/:id', async (req, res) => {
  try {
    const questId = req.params.id;
 
    const result = await Quest.deleteOne({ id: questId });
 
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Quest not found' });
    }
 
    res.json({ message: 'Quest deleted', id: questId });
  } catch (err) {
    console.error('Error deleting quest:', err);
    res.status(500).json({ message: 'Failed to delete quest' });
  }
});

app.get('/api/students/:studentId/state', async (req, res) => {
  try {
    const { studentId } = req.params;
 
    let state = await StudentState.findOne({ studentId }).lean();
 
    // auto-create if not exists
    if (!state) {
      const created = await StudentState.create({ studentId });
      state = created.toObject();
    }
 
    res.json(state);
  } catch (err) {
    console.error('Error fetching student state:', err);
    res.status(500).json({ message: 'Failed to fetch student state' });
  }
});
 
//  full student state (achievements, inventory, progress, level/xp)
app.put('/api/students/:studentId/state', async (req, res) => {
  try {
    const { studentId } = req.params;
    const {
      achievements = [],
      inventory = [],
      progress = {},
      level,
      xp
    } = req.body;
 
    const updateDoc = {
      achievements,
      inventory,
      progress
    };
 
    if (typeof level === 'number') updateDoc.level = level;
    if (typeof xp === 'number') updateDoc.xp = xp;
 
    const state = await StudentState.findOneAndUpdate(
      { studentId },
      updateDoc,
      { new: true, upsert: true }
    ).lean();
 
    res.json(state);
  } catch (err) {
    console.error('Error saving student state:', err);
    res.status(500).json({ message: 'Failed to save student state' });
  }
});
 
// Update progress for a quest and adjust level/xp
app.post('/api/students/:studentId/progress', async (req, res) => {
  try {
    const { studentId } = req.params;
    const { questId, score, xpGained } = req.body;
 
    if (!questId || typeof score !== 'number') {
      return res
        .status(400)
        .json({ message: 'questId and numeric score are required' });
    }
 
    let state = await StudentState.findOne({ studentId });
 
    if (!state) {
      state = new StudentState({ studentId });
    }
 
    // update progress map
    state.progress.set(questId, score);
 
    // update xp / level
    const gained = typeof xpGained === 'number' ? xpGained : score * 10;
    state.xp += gained;
 
    const xpForNextLevel = state.level * 100;
    while (state.xp >= xpForNextLevel) {
      state.xp -= xpForNextLevel;
      state.level += 1;
    }
 
    await state.save();
    res.json(state);
  } catch (err) {
    console.error('Error updating student progress:', err);
    res.status(500).json({ message: 'Failed to update progress' });
  }
});




 
// ===== START SERVER =====
const PORT = process.env.PORT || 5000;
 
app.listen(PORT, () => {
  console.log(`EduQuest backend running on http://localhost:${PORT}`);
});