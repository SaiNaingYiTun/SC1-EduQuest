import { useState, useEffect } from 'react';
import RoleSelection from './components/RoleSelection';
import AuthPage from './components/AuthPage';
import StudentDashboard from './components/StudentDashboard';
import TeacherDashboard from './components/TeacherDashboard';
import CharacterSelection from './components/CharacterSelection';



function App() {
  const [currentView, setCurrentView] = useState('role');
  const [selectedRole, setSelectedRole] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [allUsers, setAllUsers] = useState([
    {
      id: 'teacher1',
      username: 'prof_merlin',
      role: 'teacher',
      name: 'Professor Merlin',
      subjectName: 'Advanced Mathematics',
      otpCode: 'MATH2024'
    }
  ]);

  const [characters, setCharacters] = useState({});
  const [studentClasses, setStudentClasses] = useState({});
  const [achievements, setAchievements] = useState({});
  const [quests, setQuests] = useState([]);
  const [studentInventories, setStudentInventories] = useState({});
  const [studentProgress,setStudentProgress] = useState({});
  const [studentLevels,setStudentLevels] = useState({});

  const saveStudentState = async (
    studentId,
    achievementList,
    inventoryList,
    progressObj,
    levelInfo
  ) => {
    try {
      await fetch(`/api/students/${studentId}/state`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          achievements: achievementList,
          inventory: inventoryList,
          progress: progressObj,
          level: levelInfo.level,
          xp: levelInfo.xp
        })
      });
    } catch (err) {
      console.error('Error saving student state:', err);
    }
  };
 
  const fetchStudentState = async (studentId) => {
    try {
      const res = await fetch(`/api/students/${studentId}/state`);
      const data = await res.json();
 
      const backendAchievements = Array.isArray(data.achievements)
        ? data.achievements
        : [];
      const backendInventory = Array.isArray(data.inventory)
        ? data.inventory
        : [];
 
      const backendProgress =
        data.progress && typeof data.progress === 'object'
          ? data.progress
          : {};
 
      const level = typeof data.level === 'number' ? data.level : 1;
      const xp = typeof data.xp === 'number' ? data.xp : 0;
 
      let finalAchievements = backendAchievements;
 
      // If no achievements saved yet in backend, init with defaults
      if (backendAchievements.length === 0) {
        finalAchievements = getDefaultAchievements();
        await saveStudentState(
          studentId,
          finalAchievements,
          backendInventory,
          backendProgress,
          { level, xp }
        );
      }
 
      setAchievements((prev) => ({
        ...prev,
        [studentId]: finalAchievements
      }));
 
      setStudentInventories((prev) => ({
        ...prev,
        [studentId]: backendInventory
      }));
 
      setStudentProgress((prev) => ({
        ...prev,
        [studentId]: backendProgress
      }));
 
      setStudentLevels((prev) => ({
        ...prev,
        [studentId]: { level, xp }
      }));
    } catch (err) {
      console.error('Error loading student state:', err);
    }
  };
 
  const handleUpdateProgress = async (studentId, questId, score, xpGainedOverride) => {
    try {
      const res = await fetch(`/api/students/${studentId}/progress`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questId,
          score,
          xpGained: xpGainedOverride
        })
      });
 
      if (!res.ok) {
        throw new Error('Failed to update progress');
      }
 
      const data = await res.json();
 
      const updatedProgress =
        data.progress && typeof data.progress === 'object'
          ? data.progress
          : {};
 
      setStudentProgress((prev) => ({
        ...prev,
        [studentId]: updatedProgress
      }));
 
      setStudentLevels((prev) => ({
        ...prev,
        [studentId]: {
          level: data.level ?? 1,
          xp: data.xp ?? 0
        }
      }));
    } catch (err) {
      console.error('Error updating progress:', err);
    }
  };


  useEffect(() => {
    // Load from localStorage
    const savedUser = localStorage.getItem('currentUser');
    const savedView = localStorage.getItem('currentView');
    const savedUsers = localStorage.getItem('allUsers');
    const savedCharacters = localStorage.getItem('characters');
    const savedStudentClasses = localStorage.getItem('studentClasses');
    const savedAchievements = localStorage.getItem('achievements');
    const savedStudentInventories = localStorage.getItem('studentInventories');

    if (savedUsers) {
      setAllUsers(JSON.parse(savedUsers));
    }
    if (savedCharacters) {
      setCharacters(JSON.parse(savedCharacters));
    }
    if (savedStudentClasses) {
      setStudentClasses(JSON.parse(savedStudentClasses));
    }
    if (savedAchievements) {
      setAchievements(JSON.parse(savedAchievements));
    }
    // Always load quests from backend API (backend is source of truth)
fetch('/api/quests')
  .then((res) => res.json())
  .then((data) => {
    setQuests(data);
  })
  .catch((err) => {
    console.error('Error loading quests from backend:', err);
  });
    
    if (savedStudentInventories) {
      setStudentInventories(JSON.parse(savedStudentInventories));
    }
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      setSelectedRole(user.role);
      if (savedView) {
        setCurrentView(savedView);
      } else {
        // Determine view based on user state
        if (user.role === 'student' && !user.characterId) {
          setCurrentView('character');
        } else {
          setCurrentView('dashboard');
        }
      }
      if (user.role === 'student') {
        fetchStudentState(user.id);
      }
    }
  }, []);

  useEffect(() => {
    // Save to localStorage
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      localStorage.setItem('currentView', currentView);
    }
    localStorage.setItem('allUsers', JSON.stringify(allUsers));
    localStorage.setItem('characters', JSON.stringify(characters));
    localStorage.setItem('studentClasses', JSON.stringify(studentClasses));
    localStorage.setItem('achievements', JSON.stringify(achievements));   
    localStorage.setItem('studentInventories', JSON.stringify(studentInventories));
  }, [currentUser, currentView, allUsers, characters, studentClasses, achievements, quests, studentInventories]);

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
    setCurrentView('auth');
  };

  const handleAuth = async (username, password, isSignUp) => {
    if (isSignUp) {
      // Sign up
      const existingUser = allUsers.find(u => u.username === username);
      if (existingUser) {
        alert('Username already exists!');
        return;
      }

      const newUser = {
        id: `${selectedRole}_${Date.now()}`,
        username,
        role: selectedRole,
        name: username,
      };

      if (selectedRole === 'teacher') {
        newUser.subjectName = 'My Subject';
        newUser.otpCode = generateOTP();
      }

      setAllUsers([...allUsers, newUser]);
      setCurrentUser(newUser);

      if (selectedRole === 'student') {
        const defaultAchievements = getDefaultAchievements();
        const initialInventory = [];
        const initialProgress = {};
        const initialLevel = { level: 1, xp: 0 };
 
        setAchievements({
          ...achievements,
          [newUser.id]: defaultAchievements
        });
 
        setStudentInventories((prev) => ({
          ...prev,
          [newUser.id]: initialInventory
        }));
 
        setStudentProgress((prev) => ({
          ...prev,
          [newUser.id]: initialProgress
        }));
 
        setStudentLevels((prev) => ({
          ...prev,
          [newUser.id]: initialLevel
        }));
 
        // initialize in backend
        await saveStudentState(
          newUser.id,
          defaultAchievements,
          initialInventory,
          initialProgress,
          initialLevel
        );
        setCurrentView('character');
      } else {
        setCurrentView('dashboard');
      }
    } else {
      // Sign in
      const user = allUsers.find(u => u.username === username && u.role === selectedRole);
      if (!user) {
        alert('Invalid username or password!');
        return;
      }

      setCurrentUser(user);

      if(user.role === 'student') {
        await fetchStudentState(user.id);
      }

      if (user.role === 'student' && !user.characterId) {
        setCurrentView('character');
      } else {
        setCurrentView('dashboard');
      }
    }
  };

  const handleCharacterCreation = (character) => {
    if (!currentUser) return;

    const updatedUser = {
      ...currentUser,
      characterId: character.id
    };

    setCharacters({
      ...characters,
      [character.id]: character
    });

    setCurrentUser(updatedUser);
    setAllUsers(allUsers.map(u => u.id === updatedUser.id ? updatedUser : u));
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setSelectedRole(null);
    setCurrentView('role');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentView');
  };

  const handleUpdateUser = (updates) => {
    if (!currentUser) return;

    const updatedUser = {
      ...currentUser,
      ...updates
    };

    setCurrentUser(updatedUser);
    setAllUsers(allUsers.map(u => u.id === updatedUser.id ? updatedUser : u));
  };

  const handleUpdateCharacter = (characterId, updates) => {
    setCharacters({
      ...characters,
      [characterId]: {
        ...characters[characterId],
        ...updates
      }
    });
  };

  const handleJoinClass = (teacherUsername, otp) => {
    if (!currentUser || currentUser.role !== 'student') return;

    const teacher = allUsers.find(u => u.username === teacherUsername && u.role === 'teacher');
    if (!teacher) {
      alert('Teacher not found!');
      return false;
    }

    if (teacher.otpCode !== otp) {
      alert('Invalid OTP code!');
      return false;
    }

    const currentClasses = studentClasses[currentUser.id] || [];
    if (currentClasses.includes(teacher.id)) {
      alert('You are already in this class!');
      return false;
    }

    setStudentClasses({
      ...studentClasses,
      [currentUser.id]: [...currentClasses, teacher.id]
    });

    return true;
  };

  const handleUnlockAchievement = async (achievementId) => {
    if (!currentUser) return;

    const userId = currentUser.id;
    const userAchievements = achievements[userId] || []

    const updatedAchievements = userAchievements.map((a) =>
      a.id === achievementId && !a.unlocked
        ? { ...a, unlocked: true, unlockedAt: new Date().toISOString() }
        : a
    );
 
    const inventory = studentInventories[userId] || [];
    const progressObj = studentProgress[userId] || {};
    const levelInfo = studentLevels[userId] || { level: 1, xp: 0 };
 
    setAchievements({
      ...achievements,
      [userId]: updatedAchievements
    });
 
    await saveStudentState(
      userId,
      updatedAchievements,
      inventory,
      progressObj,
      levelInfo
    );
  };

  const handleCreateQuest = async (newQuest) => {
  try {
    const response = await fetch('/api/quests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newQuest)
    });
 
    if (!response.ok) {
      throw new Error('Failed to create quest');
    }
 
    const createdQuest = await response.json();
 
    // update local state with quest returned by backend
    setQuests((prev) => [...prev, createdQuest]);
  } catch (error) {
    console.error('Error creating quest:', error);
  }
};
 
const handleUpdateQuest = async (updatedQuest) => {
  try {
    const response = await fetch(`/api/quests/${updatedQuest.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedQuest)
    });
 
    if (!response.ok) {
      throw new Error('Failed to update quest');
    }
 
    const savedQuest = await response.json();
 
    setQuests((prev) =>
      prev.map((quest) => (quest.id === savedQuest.id ? savedQuest : quest))
    );
  } catch (error) {
    console.error('Error updating quest:', error);
  }
};
 
const handleDeleteQuest = async (questId) => {
  try {
    const response = await fetch(`/api/quests/${questId}`, {
      method: 'DELETE'
    });
 
    if (!response.ok) {
      throw new Error('Failed to delete quest');
    }
 
    // we could read the JSON response if we want, but not needed
    setQuests((prev) => prev.filter((quest) => quest.id !== questId));
  } catch (error) {
    console.error('Error deleting quest:', error);
  }
};

  const handleAddItemToInventory = async (studentId, item) => {
    const newInventory = [...(studentInventories[studentId] || []), item];
 
    const achievementList =
      achievements[studentId] || getDefaultAchievements();
    const progressObj = studentProgress[studentId] || {};
    const levelInfo = studentLevels[studentId] || { level: 1, xp: 0 };
 
    setStudentInventories({
      ...studentInventories,
      [studentId]: newInventory
    });
 
    await saveStudentState(
      studentId,
      achievementList,
      newInventory,
      progressObj,
      levelInfo
    );
  };

  const generateOTP = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let otp = '';
    for (let i = 0; i < 8; i++) {
      otp += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return otp;
  };

  const getDefaultAchievements = () => [
    {
      id: 'first_quest',
      title: 'First Steps',
      description: 'Complete your first quest',
      icon: '🎯',
      unlocked: false
    },
    {
      id: 'level_5',
      title: 'Apprentice Scholar',
      description: 'Reach level 5',
      icon: '📚',
      unlocked: false
    },
    {
      id: 'level_10',
      title: 'Expert Adventurer',
      description: 'Reach level 10',
      icon: '⚔️',
      unlocked: false
    },
    {
      id: 'perfect_score',
      title: 'Perfectionist',
      description: 'Get a perfect score on a quest',
      icon: '💯',
      unlocked: false
    },
    {
      id: 'speed_demon',
      title: 'Speed Demon',
      description: 'Complete a timed quest with 50% time remaining',
      icon: '⚡',
      unlocked: false
    },
    {
      id: 'class_joiner',
      title: 'Class Joined',
      description: 'Join your first class',
      icon: '🏫',
      unlocked: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900 to-slate-900">
      {currentView === 'role' && (
        <RoleSelection onSelectRole={handleRoleSelect} />
      )}
      
      {currentView === 'auth' && selectedRole && (
        <AuthPage role={selectedRole} onAuth={handleAuth} onBack={() => setCurrentView('role')} />
      )}
      
      {currentView === 'character' && currentUser && currentUser.role === 'student' && (
        <CharacterSelection onCharacterCreated={handleCharacterCreation} userId={currentUser.id} />
      )}
      
      {currentView === 'dashboard' && currentUser && currentUser.role === 'student' && (
        <StudentDashboard
          user={currentUser}
          character={currentUser.characterId ? characters[currentUser.characterId] : undefined}
          onLogout={handleLogout}
          onUpdateUser={handleUpdateUser}
          onUpdateCharacter={handleUpdateCharacter}
          onJoinClass={handleJoinClass}
          studentClasses={studentClasses[currentUser.id] || []}
          teachers={allUsers.filter(u => u.role === 'teacher')}
          achievements={achievements[currentUser.id] || []}
          onUnlockAchievement={handleUnlockAchievement}
          quests={quests}
          inventory={studentInventories[currentUser.id] || []}
        />
      )}
      
      {currentView === 'dashboard' && currentUser && currentUser.role === 'teacher' && (
        <TeacherDashboard
          user={currentUser}
          onLogout={handleLogout}
          onUpdateUser={handleUpdateUser}
          students={allUsers.filter(u => 
            u.role === 'student' && 
            (studentClasses[u.id] || []).includes(currentUser.id)
          )}
          allStudents={allUsers.filter(u => u.role === 'student')}
          characters={characters}
          studentClasses={studentClasses}
          onInviteStudent={(studentId) => {
            setStudentClasses({
              ...studentClasses,
              [studentId]: [...(studentClasses[studentId] || []), currentUser.id]
            });
          }}
          onCreateQuest={handleCreateQuest}
          onUpdateQuest={handleUpdateQuest}
          onDeleteQuest={handleDeleteQuest}
          onAddItemToInventory={handleAddItemToInventory}
          quests={quests}
        />
      )}
    </div>
  );
}

export default App;