// ✅ NEW (Tailwind v4)
module.exports = {
  plugins: {
    "@tailwindcss/postcss": {},
  },
}
